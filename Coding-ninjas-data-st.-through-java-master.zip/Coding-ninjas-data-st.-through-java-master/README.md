# Coding ninjas data structure through java all solutions
